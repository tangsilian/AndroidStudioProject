# RedEnvelopeAssistant
Red Envelope Assistant  
以下是一份英文介绍:
[中文](/README.md)  


---
**PLEASE NOTE, THIS PROJECT IS NO LONGER BEING MAINTAINED**  
A totally opensource(MIT license) Red Envelope Assistant android client.

This application is intended for Chinese popular android application Wechat and Alipay. A Tool help you get the red envelopes more conveniently.
If you are not a user of both the two applications, this application may not suit you well.

#Download And Video
If you want to know more, check out the apk file  and video.

Download
only available for Android 4.4+
https://github.com/waylife/RedEnvelopeAssistant/tree/master/APK

Video     https://github.com/waylife/RedEnvelopeAssistant/tree/master/Video


#Compile
##Eclipse
File->Import->Android->Existing Android Code into workspace

##Android Studio
Import project(Eclisep ADT,Gradle,etc.) for AS 1.0+



#Reference
1. AccessibilityService http://developer.android.com/intl/zh-cn/reference/android/accessibilityservice/AccessibilityService.html
2. ROOT https://github.com/Stericson/RootTools  
3. Notification click http://download.csdn.net/detail/a332324956/8456633
4. Appmall http://app.sogou.com/m
